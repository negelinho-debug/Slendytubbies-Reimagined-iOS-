import io
import json
import struct
import sys
from pathlib import Path

from PIL import Image


LIMIT = 2048


def resize(image, destination, image_format):
    image.thumbnail((LIMIT, LIMIT), Image.Resampling.LANCZOS)
    options = {"quality": 90} if image_format == "JPEG" else {}
    image.save(destination, format=image_format, **options)


def pad(data, fill=b"\0"):
    return data + fill * (-len(data) % 4)


def resize_model(path):
    glb = path.read_bytes()
    magic, version, _, manifest_length, manifest_type = struct.unpack_from("<4sIIII", glb)
    offset = 20 + manifest_length
    binary_length, binary_type = struct.unpack_from("<II", glb, offset)
    if (magic, version, manifest_type, binary_type) != (b"glTF", 2, 0x4E4F534A, 0x004E4942):
        raise ValueError(f"Unsupported model format: {path.name}")
    document = json.loads(glb[20:offset])
    original = memoryview(glb)[offset + 8:offset + 8 + binary_length]
    images = {image["bufferView"] for image in document.get("images", []) if "bufferView" in image}
    changes = {}
    for index in images:
        view = document["bufferViews"][index]
        start = view.get("byteOffset", 0)
        with Image.open(io.BytesIO(original[start:start + view["byteLength"]])) as image:
            if max(image.size) > LIMIT:
                resized = io.BytesIO()
                resize(image, resized, image.format)
                changes[index] = resized.getvalue()
    if not changes:
        return

    if len(document["buffers"]) != 1:
        raise ValueError(f"Unsupported buffer layout: {path.name}")
    rebuilt = bytearray()
    for index, view in enumerate(document["bufferViews"]):
        start = view.get("byteOffset", 0)
        data = changes.get(index, original[start:start + view["byteLength"]])
        view["byteOffset"] = len(rebuilt)
        view["byteLength"] = len(data)
        rebuilt.extend(data)
        rebuilt.extend(b"\0" * (-len(rebuilt) % 4))
    document["buffers"][0]["byteLength"] = len(rebuilt)
    manifest = pad(json.dumps(document, separators=(",", ":")).encode(), b" ")
    header = struct.pack("<4sIIII", magic, version, 28 + len(manifest) + len(rebuilt),
                         len(manifest), manifest_type)
    path.write_bytes(header + manifest + struct.pack("<II", len(rebuilt), binary_type) + rebuilt)
    print(f"Resized {len(changes)} textures in {path.name}")


def main():
    assets = Path(sys.argv[1]) / "assets"
    dirt = assets / "textures" / "dirt.png"
    with Image.open(dirt) as image:
        resize(image, dirt, "PNG")
    for model in sorted((assets / "models").glob("*.glb")):
        resize_model(model)


if __name__ == "__main__":
    main()
