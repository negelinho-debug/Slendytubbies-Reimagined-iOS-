#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

static NSString * const GameScheme = @"reimagined";

@interface GameFiles : NSObject <WKURLSchemeHandler, WKScriptMessageHandler>
@property (nonatomic, strong) NSURL *root;
@end

@implementation GameFiles

- (instancetype)init {
    self = [super init];
    if (self) {
        _root = [[NSBundle mainBundle].resourceURL URLByAppendingPathComponent:@"Game" isDirectory:YES];
    }
    return self;
}

- (void)webView:(WKWebView *)webView startURLSchemeTask:(id<WKURLSchemeTask>)task {
    NSURL *requestURL = task.request.URL;
    NSString *relative = [requestURL.path substringFromIndex:MIN(requestURL.path.length, 1)];
    if (relative.length == 0) relative = @"index.html";
    NSURL *fileURL = [[self.root URLByAppendingPathComponent:relative] URLByStandardizingPath];
    NSString *rootPrefix = [[self.root URLByStandardizingPath].path stringByAppendingString:@"/"];
    NSData *file = nil;
    if ([requestURL.host isEqualToString:@"localhost"] && [fileURL.path hasPrefix:rootPrefix]) {
        file = [NSData dataWithContentsOfURL:fileURL options:NSDataReadingMappedIfSafe error:NULL];
    }

    NSDictionary *types = @{
        @"html": @"text/html; charset=utf-8", @"css": @"text/css; charset=utf-8",
        @"js": @"text/javascript; charset=utf-8", @"png": @"image/png",
        @"jpg": @"image/jpeg", @"jpeg": @"image/jpeg", @"webp": @"image/webp",
        @"mp3": @"audio/mpeg", @"wav": @"audio/wav", @"ogg": @"audio/ogg",
        @"woff2": @"font/woff2", @"glb": @"model/gltf-binary",
    };
    NSString *mime = types[fileURL.pathExtension.lowercaseString] ?: @"application/octet-stream";
    NSInteger status = file ? 200 : 404;
    NSData *body = file ?: [NSData data];
    NSMutableDictionary *headers = [@{
        @"Content-Type": mime,
        @"Access-Control-Allow-Origin": @"*",
        @"Accept-Ranges": @"bytes"
    } mutableCopy];
    NSString *rangeHeader = [task.request valueForHTTPHeaderField:@"Range"];
    if (file && [rangeHeader hasPrefix:@"bytes="]) {
        NSArray<NSString *> *parts = [[rangeHeader substringFromIndex:6] componentsSeparatedByString:@"-"];
        NSCharacterSet *nonDigits = NSCharacterSet.decimalDigitCharacterSet.invertedSet;
        BOOL valid = parts.count == 2 && (parts[0].length || parts[1].length)
            && [parts[0] rangeOfCharacterFromSet:nonDigits].location == NSNotFound
            && [parts[1] rangeOfCharacterFromSet:nonDigits].location == NSNotFound
            && file.length > 0;
        if (valid) {
            unsigned long long end = file.length - 1;
            unsigned long long start = parts[0].longLongValue;
            if (!parts[0].length) {
                unsigned long long suffix = parts[1].longLongValue;
                start = suffix >= file.length ? 0 : file.length - suffix;
            } else if (parts[1].length) {
                end = MIN(end, (unsigned long long)parts[1].longLongValue);
            }
            if (start <= end) {
                body = [file subdataWithRange:NSMakeRange((NSUInteger)start, (NSUInteger)(end-start+1))];
                status = 206;
                headers[@"Content-Range"] = [NSString stringWithFormat:@"bytes %llu-%llu/%lu",
                                              start, end, (unsigned long)file.length];
            }
        }
        if (status != 206) {
            status = 416;
            body = [NSData data];
            headers[@"Content-Range"] = [NSString stringWithFormat:@"bytes */%lu", (unsigned long)file.length];
        }
    }
    headers[@"Content-Length"] = [NSString stringWithFormat:@"%lu", (unsigned long)body.length];
    NSHTTPURLResponse *response = [[NSHTTPURLResponse alloc] initWithURL:requestURL
        statusCode:status HTTPVersion:@"HTTP/1.1" headerFields:headers];
    [task didReceiveResponse:response];
    if (body.length && ![task.request.HTTPMethod isEqualToString:@"HEAD"]) [task didReceiveData:body];
    [task didFinish];
}

- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id<WKURLSchemeTask>)task {
    // Each response is sent synchronously on the WebKit callback queue.
}

- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
    if (!message.frameInfo.isMainFrame || ![message.body isKindOfClass:NSDictionary.class]) return;
    NSDictionary *setting = message.body;
    NSString *key = setting[@"key"];
    NSString *value = setting[@"value"];
    BOOL language = [key isEqual:@"port-language"] && [@[@"en", @"ru", @"uk"] containsObject:value ?: @""];
    BOOL unlocked = [key isEqual:@"archivosDesbloqueados"] && [value isEqual:@"true"];
    if (language || unlocked) [NSUserDefaults.standardUserDefaults setObject:value forKey:key];
}
@end

@interface GameViewController : UIViewController
@end

@implementation GameViewController
- (void)loadView {
    WKWebViewConfiguration *configuration = [WKWebViewConfiguration new];
    configuration.allowsInlineMediaPlayback = YES;
    configuration.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeNone;
    GameFiles *files = [GameFiles new];
    [configuration setURLSchemeHandler:files forURLScheme:GameScheme];
    [configuration.userContentController addScriptMessageHandler:files name:@"portSettings"];
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    NSDictionary *settings = @{
        @"port-language": [defaults stringForKey:@"port-language"] ?: @"en",
        @"archivosDesbloqueados": [defaults stringForKey:@"archivosDesbloqueados"] ?: @"false"
    };
    NSData *json = [NSJSONSerialization dataWithJSONObject:settings options:0 error:NULL];
    NSString *script = [@"window.portNativeSettings = "
                        stringByAppendingString:[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding]];
    [configuration.userContentController addUserScript:[[WKUserScript alloc] initWithSource:script
        injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:YES]];
    WKWebView *webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:configuration];
    webView.opaque = NO;
    webView.backgroundColor = UIColor.blackColor;
    webView.scrollView.scrollEnabled = NO;
    webView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.view = webView;
    NSURL *url = [NSURL URLWithString:@"reimagined://localhost/index.html"];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}
- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)prefersHomeIndicatorAutoHidden { return YES; }
@end

@interface GameAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation GameAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [GameViewController new];
    [self.window makeKeyAndVisible];
    application.idleTimerDisabled = YES;
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(GameAppDelegate.class));
    }
}
