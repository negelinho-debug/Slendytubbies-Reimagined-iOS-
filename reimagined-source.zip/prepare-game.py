import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"Upstream anchor changed: {old}")
    return text.replace(old, new, 1)


def edit(file, callback):
    file.write_text(callback(file.read_text(encoding="utf-8")), encoding="utf-8")


def patch_html(text):
    text = re.sub(r'<link[^>]+(?:fonts.googleapis.com|fonts.gstatic.com)[^>]*>\s*', '', text)
    text = re.sub(r'<script type="importmap">.*?</script>\s*', '', text, count=1, flags=re.S)
    text = re.sub(r'<script[^>]+static\.itch\.io/htmlgame\.js[^>]*></script>', '', text)
    text = replace_once(text, '</head>', '<link href="./port.css" rel="stylesheet">\n</head>')
    text = replace_once(text, 'initial-scale=1.0', 'initial-scale=1.0, viewport-fit=cover')
    text = text.replace('Mouse Sensitivity:', 'Look Sensitivity:')
    text = text.replace('BATERÍA: 100%', 'BATTERY: 100%')
    text = text.replace('assets/images/screamer.jpg', 'assets/images/screamer1.png')
    text, count = re.subn(
        r'<p style="color: #aaaaaa; font-size: 18px;">\s*<i>P\.D\..*?</p>',
        '<p>Drag the left stick to move. Swipe on the right to look. '
        'Hold Run to sprint and tap Light to toggle your flashlight.</p>',
        text, count=1, flags=re.S
    )
    if count != 1:
        raise ValueError("The briefing input instructions changed")
    picker = '''
        <label class="port-option" for="port-language">
            <span>Language</span>
            <select id="port-language">
                <option value="en" lang="en">English</option>
                <option value="ru" lang="ru">Русский</option>
                <option value="uk" lang="uk">Українська</option>
            </select>
        </label>'''
    text, count = re.subn(
        r'(id="sensSlider"[^>]+>\s*</div>)', lambda match: match[1] + picker, text, count=1
    )
    if count != 1:
        raise ValueError("The settings input changed")
    controls = '''
    <div id="port-touch" hidden>
        <div id="port-look" aria-hidden="true"></div>
        <div id="port-stick" aria-hidden="true"><div id="port-knob"></div></div>
        <button id="port-run" type="button">Run</button>
        <button id="port-light" type="button" aria-pressed="false">Light</button>
        <button id="port-pause" type="button">Pause</button>
    </div>
    <script src="./locale.js"></script>
    <script defer src="./game-bundle.js"></script>'''
    text = replace_once(text, '<script type="module" src="./js/game.js"></script>', controls)
    # The inline menu script above the locale script only runs these assignments on user clicks.
    return localize_assignments(text.replace('localStorage.', 'window.portStorage.'), r'btnAbrirPersonajes')


def localize_assignments(text, targets):
    expression = r"""(?P<quote>['"])(?:\\.|(?!(?P=quote))[^\r\n])*?(?P=quote)"""
    return re.sub(
        rf"\b({targets})\.innerText\s*=\s*({expression}|frase);",
        r"window.portSetText(\1, \2);",
        text
    )


def patch_player(text):
    text = replace_once(
        text,
        "import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';",
        "import { TouchControls } from './touch-controls.js';"
    )
    text = replace_once(
        text, 'new PointerLockControls(this.camera, document.body)', 'new TouchControls(this.camera)'
    )
    text = text.replace('shadow.mapSize.width = 2048', 'shadow.mapSize.width = 512')
    text = text.replace('shadow.mapSize.height = 2048', 'shadow.mapSize.height = 512')
    text = text.replace('"BATTERY: " +', 'window.portText("BATTERY:") + " " +')
    return re.sub(
        r'batteryText\.innerText = "(BATTERY: LOW|RECHARGING\.\.\.)";',
        r'batteryText.innerText = window.portText("\1");', text
    )


def patch_game(text):
    text = "import { installTouchControls } from './touch-controls.js';\n" + text
    text = replace_once(
        text, '        this.bindEvents();',
        '''        this.bindEvents();
        window.exitGameLook = () => this.player.controls.unlock();
        this.refreshTouchControls = installTouchControls(this);'''
    )
    text = replace_once(text, '                    this.animate();', '')
    text = replace_once(
        text, 'requestAnimationFrame(() => this.animate());',
        'requestAnimationFrame(() => this.animate());\n        this.refreshTouchControls();'
    )
    text = replace_once(text, 'new THREE.WebGLRenderer({ antialias: true })',
                        'new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" })')
    text = replace_once(text, 'const delta = this.clock.getDelta();', 'const delta = Math.min(this.clock.getDelta(), 0.05);')
    text = replace_once(text, 'const rainCount = 6000;', 'const rainCount = 2400;')
    text = replace_once(text, '                    this.audio.playAmbient();',
                        '''                    this.audio.listener.context.resume().catch(console.warn);
                    this.audio.playAmbient();''')
    return localize_assignments(text.replace('localStorage.', 'window.portStorage.'),
                                r'sub|subElem|titleText|btnUnlock|winText|descText')


def main():
    source = Path(sys.argv[1])
    target = Path(sys.argv[2])
    shutil.copytree(source, target, dirs_exist_ok=True)
    edit(target / "index.html", patch_html)
    edit(target / "js" / "player.js", patch_player)
    edit(target / "js" / "game.js", patch_game)
    for name in ("ai.js", "ui.js"):
        edit(target / "js" / name, lambda text: text.replace("document.exitPointerLock()", "window.exitGameLook()"))
    for name, directory in (("touch-controls.js", "js"), ("port.css", ""), ("locale.js", "")):
        shutil.copyfile(ROOT / "patch" / name, target / directory / name)


if __name__ == "__main__":
    main()
