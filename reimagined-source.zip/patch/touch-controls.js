import { EventDispatcher, Euler, MathUtils, Vector3 } from 'three';

export class TouchControls extends EventDispatcher {
    constructor(camera) {
        super();
        this.camera = camera;
        this.enabled = true;
        this.isLocked = false;
        this.pointerSpeed = 1;
        this.rotation = new Euler(0, 0, 0, 'YXZ');
        this.axis = new Vector3();
    }

    lock() {
        if (this.isLocked) return;
        this.isLocked = true;
        this.dispatchEvent({ type: 'lock' });
    }

    unlock() {
        if (!this.isLocked) return;
        this.isLocked = false;
        this.dispatchEvent({ type: 'unlock' });
    }

    getObject() {
        return this.camera;
    }

    moveRight(distance) {
        this.axis.setFromMatrixColumn(this.camera.matrix, 0);
        this.camera.position.addScaledVector(this.axis, distance);
    }

    moveForward(distance) {
        this.axis.setFromMatrixColumn(this.camera.matrix, 0);
        this.axis.crossVectors(this.camera.up, this.axis);
        this.camera.position.addScaledVector(this.axis, distance);
    }

    look(dx, dy) {
        if (!this.isLocked || !this.enabled) return;
        const speed = this.pointerSpeed * 0.004;
        this.rotation.setFromQuaternion(this.camera.quaternion);
        this.rotation.y -= dx * speed;
        this.rotation.x = MathUtils.clamp(this.rotation.x - dy * speed, -1.54, 1.54);
        this.camera.quaternion.setFromEuler(this.rotation);
    }
}

export function installTouchControls(game) {
    const player = game.player;
    const controls = player.controls;
    const hud = document.getElementById('port-touch');
    const stick = document.getElementById('port-stick');
    const knob = document.getElementById('port-knob');
    const look = document.getElementById('port-look');
    const run = document.getElementById('port-run');
    const pause = document.getElementById('port-pause');
    const light = document.getElementById('port-light');

    function releaseInputs() {
        player.moveForward = player.moveBackward = false;
        player.moveLeft = player.moveRight = false;
        player.isSprinting = false;
        knob.style.translate = '0 0';
        run.classList.remove('pressed');
    }

    function updateStick(event) {
        const rect = stick.getBoundingClientRect();
        const x = event.clientX - rect.left - rect.width / 2;
        const y = event.clientY - rect.top - rect.height / 2;
        const distance = Math.hypot(x, y);
        const scale = distance === 0 ? 0 : Math.min(1, 32 / distance);
        knob.style.translate = `${x * scale}px ${y * scale}px`;
        player.moveForward = y * scale < -7;
        player.moveBackward = y * scale > 7;
        player.moveLeft = x * scale < -7;
        player.moveRight = x * scale > 7;
    }

    function bindDrag(element, start, move, end) {
        let active = null;
        element.addEventListener('pointerdown', event => {
            if (active !== null) return;
            event.preventDefault();
            active = event.pointerId;
            element.setPointerCapture(active);
            start?.(event);
        });
        element.addEventListener('pointermove', event => {
            if (active === event.pointerId) move?.(event);
        });
        for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
            element.addEventListener(type, event => {
                if (active !== event.pointerId) return;
                active = null;
                end?.();
            });
        }
    }

    bindDrag(stick, updateStick, updateStick, () => {
        player.moveForward = player.moveBackward = false;
        player.moveLeft = player.moveRight = false;
        knob.style.translate = '0 0';
    });
    let lastX = 0;
    let lastY = 0;
    bindDrag(look, event => {
        lastX = event.clientX;
        lastY = event.clientY;
    }, event => {
        controls.look(event.clientX - lastX, event.clientY - lastY);
        lastX = event.clientX;
        lastY = event.clientY;
    });
    bindDrag(run, () => {
        player.isSprinting = true;
        run.classList.add('pressed');
    }, null, () => {
        player.isSprinting = false;
        run.classList.remove('pressed');
    });
    light.addEventListener('click', () => {
        document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyF' }));
    });
    pause.addEventListener('click', () => controls.unlock());
    window.addEventListener('blur', releaseInputs);
    document.addEventListener('visibilitychange', () => {
        if (document.hidden && !game.isIntroActive && !game.isWinning) controls.unlock();
        if (document.hidden) releaseInputs();
    });

    return () => {
        const visible = controls.isLocked && controls.enabled && !game.isPaused &&
            !game.isIntroActive && !game.isGameOverDone &&
            (!game.isWinning || game.winPhase === 'escape');
        if (!visible && !hud.hidden) releaseInputs();
        hud.hidden = !visible;
        pause.hidden = game.isWinning;
        light.setAttribute('aria-pressed', String(player.flashlight.visible));
    };
}
