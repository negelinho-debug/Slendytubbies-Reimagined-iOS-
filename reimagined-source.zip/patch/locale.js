(() => {
    const phrases = new Map([
        ['Enter the DARKNESS', 'Войти во тьму', 'Увійти в темряву'],
        ['Characters', 'Персонажи', 'Персонажі'],
        ['Settings', 'Настройки', 'Налаштування'],
        ['Credits', 'Авторы', 'Автори'],
        ['← Back', '← Назад', '← Назад'],
        ['Configuration', 'Настройки', 'Налаштування'],
        ['General Volume:', 'Громкость:', 'Гучність:'],
        ['Look Sensitivity:', 'Чувствительность обзора:', 'Чутливість огляду:'],
        ['Language', 'Язык', 'Мова'],
        ['Run', 'Бег', 'Біг'],
        ['Light', 'Фонарик', 'Ліхтарик'],
        ['Pause', 'Пауза', 'Пауза'],
        ['Drag the left stick to move. Swipe on the right to look. Hold Run to sprint and tap Light to toggle your flashlight.', 'Двигайся джойстиком слева. Поворачивай камеру свайпом справа. Удерживай «Бег», чтобы ускориться, и нажимай «Фонарик», чтобы включить или выключить свет.', 'Рухайся джойстиком ліворуч. Повертай камеру свайпом праворуч. Утримуй «Біг», щоб прискоритися, і натискай «Ліхтарик», щоб увімкнути або вимкнути світло.'],
        ['Start Investigation', 'Начать расследование', 'Почати розслідування'],
        ['From C.O.A.T: URGENT #Guardian.', 'От C.O.A.T. СРОЧНО, Стражу.', 'Від C.O.A.T. ТЕРМІНОВО, Вартовому.'],
        ["Something has gone terribly wrong. We've lost all contact and control over the area, and Noo-Noo the robot has disappeared from the dome; he's nowhere to be found.", 'Что-то пошло не так. Мы потеряли связь с районом и контроль над ним. Робот Ну-Ну исчез из купола, и мы не можем его найти.', 'Щось пішло не так. Ми втратили зв’язок із районом і контроль над ним. Робот Ну-Ну зник із купола, і ми не можемо його знайти.'],
        ["Go in immediately, investigate the cause of this mess—what or who is responsible—and retrieve the experimental custards scattered around the area. We believe it's the key to this anomaly, since the custard machine stopped working.", 'Немедленно отправляйся туда. Выясни, кто или что за этим стоит, и собери образцы экспериментального крема. Машина для крема перестала работать. Возможно, образцы помогут понять причину.', 'Негайно вирушай туди. З’ясуй, хто або що за цим стоїть, і збери зразки експериментального крему. Машина для крему перестала працювати. Можливо, зразки допоможуть з’ясувати причину.'],
        ["Be very careful out there... don't stop looking over your shoulder, you've seen what it is, don't let it catch you off guard...", 'Будь осторожен. Оглядывайся. Ты уже видел, что там бродит. Не дай ему застать тебя врасплох…', 'Будь обережний. Озирайся. Ти вже бачив, що там блукає. Не дай йому заскочити тебе зненацька…'],
        ['CUSTARDS:', 'КРЕМ:', 'КРЕМ:'],
        ['Collect all the experimental CUSTARDS', 'Собери все образцы экспериментального крема', 'Збери всі зразки експериментального крему'],
        ['BATTERY:', 'ЗАРЯД:', 'ЗАРЯД:'],
        ['BATTERY: LOW', 'НИЗКИЙ ЗАРЯД', 'НИЗЬКИЙ ЗАРЯД'],
        ['RECHARGING...', 'ЗАРЯЖАЕТСЯ…', 'ЗАРЯДЖАЄТЬСЯ…'],
        ['Original Game and Concept:', 'Оригинальная игра и идея:', 'Оригінальна гра та ідея:'],
        ['Original Character Design:', 'Оригинальный дизайн персонажей:', 'Оригінальний дизайн персонажів:'],
        ['Web Port Developer and Director:', 'Автор и режиссёр веб-версии:', 'Автор і режисер вебверсії:'],
        ['Code Engineering and Artificial Intelligence:', 'Программирование и ИИ:', 'Програмування та ШІ:'],
        ['CLASSIFIED FILES - TEST SUBJECTS', 'СЕКРЕТНЫЕ ФАЙЛЫ — ПОДОПЫТНЫЕ', 'СЕКРЕТНІ ФАЙЛИ — ПІДДОСЛІДНІ'],
        ['SUBJECT: Tinky Winky (Patient Zero)', 'Тинки-Винки (нулевой пациент)', 'Тінкі-Вінкі (нульовий пацієнт)'],
        ['The oldest of the group. After consuming the first infected porridge during the night, he lost his mind and massacred the rest of the subjects. His face displays a pale, lifeless smile. He frequents the Main Earth.', 'Самый старший в группе. Ночью он съел заражённый крем, потерял рассудок и напал на остальных. На его лице застыла безжизненная улыбка. Его часто видят на главной территории.', 'Найстарший у групі. Уночі він з’їв заражений крем, утратив розум і напав на решту. На його обличчі застигла нежива усмішка. Його часто бачать на головній території.'],
        ['Threat Level: EXTREME (MUTTING).', 'Угроза: КРАЙНЯЯ (МУТИРУЕТ).', 'Загроза: НАДЗВИЧАЙНА (МУТУЄ).'],
        ['SUBJECT: Dipsy (Struck and Massacred)', 'Дипси (погиб при нападении)', 'Діпсі (загинув під час нападу)'],
        ['Recognizable by his classic c#w h#t. He was ambushed in the Dome and brutally murdered.', 'Его легко узнать по пятнистой шляпе. На него напали в куполе.', 'Його легко впізнати за плямистим капелюхом. На нього напали в куполі.'],
        ['Threat Level: NULL (DEAD).', 'Угроза: НЕТ (МЁРТВ).', 'Загроза: ВІДСУТНЯ (МЕРТВИЙ).'],
        ['SUBJECT: Laa-Laa (Traumatic Blindness)', 'Ляля (ослепла после травмы)', 'Ляля (осліпла після травми)'],
        ['She tried to hide in the Ruins but was caught. A massive blow shattered her eye sockets, leaving her permanently blind. The infection keeps her alive in a state of constant agony.', 'Она попыталась спрятаться в руинах, но её поймали. После сильного удара она потеряла зрение. Инфекция всё ещё поддерживает в ней жизнь.', 'Вона спробувала сховатися в руїнах, але її спіймали. Після сильного удару вона втратила зір. Зараження досі підтримує в ній життя.'],
        ['Threat Level: NULL (PARTIALLY ALIVE).', 'Угроза: НЕТ (ЧАСТИЧНО ЖИВА).', 'Загроза: ВІДСУТНЯ (ЧАСТКОВО ЖИВА).'],
        ['SUBJECT: Po (Hanged)', 'По (повешена)', 'По (повішена)'],
        ['The youngest. She was cornered near the sacred tree and hung from one of its branches.', 'Самая младшая. Её загнали к священному дереву и повесили на одной из ветвей.', 'Наймолодша. Її загнали до священного дерева й повісили на одній із гілок.'],
        ['Threat Level: NULL (DEAD)', 'Угроза: НЕТ (МЕРТВА)', 'Загроза: ВІДСУТНЯ (МЕРТВА)'],
        ['SUBJECT: Guardián (Escaped)', 'Страж (сбежал)', 'Вартовий (утік)'],
        ['Tasked with monitoring the subjects from the underground bunker. After witnessing the massacre through the cameras, he has surfaced to collect the infected mush and uncover the truth. He is armed with nothing but a flashlight and his stamina.', 'Следил за подопытными из подземного бункера. Увидев нападение на камерах, вышел на поверхность за заражённым кремом и ответами. У него есть только фонарик и выносливость.', 'Стежив за піддослідними з підземного бункера. Побачивши напад на камерах, вийшов на поверхню по заражений крем і відповіді. У нього є лише ліхтарик і витривалість.'],
        ['Threat Level: NULL (ALIVE, STATION NEXT DESTINATION)', 'Угроза: НЕТ (ЖИВ, ИДЁТ К СТАНЦИИ)', 'Загроза: ВІДСУТНЯ (ЖИВИЙ, ІДЕ ДО СТАНЦІЇ)'],
        ['Confidential Files - Characters [LOCKED]', 'Секретные файлы [ЗАКРЫТО]', 'Секретні файли [ЗАЧИНЕНО]'],
        ['Confidential Files - Characters', 'Секретные файлы', 'Секретні файли'],
        ['¡SURVIVE TO UNLOCK!', 'ВЫЖИВИ, ЧТОБЫ ОТКРЫТЬ!', 'ВИЖИВИ, ЩОБ ВІДКРИТИ!'],
        ['Test Files', 'Досье', 'Досьє'],
        ['GAME PAUSED', 'ПАУЗА', 'ПАУЗА'],
        ['Continue', 'Продолжить', 'Продовжити'],
        ['Return to Main Menu', 'В главное меню', 'До головного меню'],
        ['TINKY CATCH YOU', 'ТИНКИ ПОЙМАЛ ТЕБЯ', 'ТІНКІ СПІЙМАВ ТЕБЕ'],
        ['¡SOBREVIVISTE!', 'ТЫ ВЫЖИЛ!', 'ТИ ВИЖИВ!'],
        ['You collected the 10 experimental CUSTARDS', 'Ты собрал все 10 образцов крема', 'Ти зібрав усі 10 зразків крему'],
        ['You Escaped!', 'Ты сбежал!', 'Ти втік!'],
        ['YOU FAILED TO ESCAPE...', 'ТЫ НЕ СМОГ СБЕЖАТЬ…', 'ТИ НЕ ЗМІГ УТЕКТИ…'],
        ['To be continued in SR2...', 'Продолжение в SR2…', 'Продовження в SR2…'],
        ['"Tinky Winky caught you!..."', '«Тинки-Винки поймал тебя!»', '«Тінкі-Вінкі спіймав тебе!»'],
        ['¡N-NO, BYE, A**H*LE!', 'Н-НЕТ! ПОКА, ПРИДУРОК!', 'Н-НІ! БУВАЙ, ПРИДУРКУ!'],
        ['¡RUN TO THE BUNKER!', 'БЕГИ К БУНКЕРУ!', 'БІЖИ ДО БУНКЕРА!'],
        ['¿¡W-WHAT!?', 'Ч-ЧТО?!', 'Щ-ЩО?!'],
        ['- Guardian: How could this have happened?', 'Страж: Как это могло случиться?', 'Вартовий: Як це могло статися?'],
        ['But what have they done to you, Po...', 'Что же они с тобой сделали, По…', 'Що ж вони з тобою зробили, По…'],
        ["It looks like it's Dipsy...", 'Похоже, это Дипси…', 'Схоже, це Діпсі…'],
        ['The air here feels so heavy... it smells like death.', 'Воздух здесь тяжёлый… пахнет смертью.', 'Повітря тут важке… пахне смертю.'],
        ["I keep hearing things in the distance. I'm going crazy.", 'Я всё время слышу что-то вдали. Я схожу с ума.', 'Я постійно щось чую вдалині. Я божеволію.'],
        ["My hands won't stop shaking... I know I'm being watched.", 'Руки не перестают дрожать… за мной кто-то следит.', 'Руки не перестають тремтіти… за мною хтось стежить.'],
        ["I just need one more... please, I have to get out of this hell.", 'Остался ещё один… надо выбраться из этого ада.', 'Лишився ще один… треба вибратися з цього пекла.']
    ].map(([source, ru, uk]) => [source, { ru, uk }]));

    const english = new Map([
        ['¡SURVIVE TO UNLOCK!', 'SURVIVE TO UNLOCK!'],
        ['¡SOBREVIVISTE!', 'YOU SURVIVED!'],
        ['TINKY CATCH YOU', 'TINKY CAUGHT YOU'],
        ['¡N-NO, BYE, A**H*LE!', 'N-NO, BYE, A**H*LE!'],
        ['¡RUN TO THE BUNKER!', 'RUN TO THE BUNKER!'],
        ['¿¡W-WHAT!?', 'W-WHAT!?']
    ]);
    const languages = ['en', 'ru', 'uk'];
    const settings = { ...window.portNativeSettings };
    const nativeStore = window.webkit?.messageHandlers?.portSettings;
    const storage = {
        getItem(key) {
            if (nativeStore) return settings[key] ?? null;
            try { return localStorage.getItem(key); } catch { return settings[key] ?? null; }
        },
        setItem(key, value) {
            settings[key] = value;
            if (nativeStore) {
                nativeStore.postMessage({ key, value });
                return;
            }
            try { localStorage.setItem(key, value); } catch { /* Use the in-memory value. */ }
        },
    };
    window.portStorage = storage;
    let language = storage.getItem('port-language');
    if (!languages.includes(language)) language = 'en';

    function translate(source) {
        return phrases.get(source)?.[language] ?? english.get(source) ?? source;
    }

    const staticText = new Map();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
        const node = walker.currentNode;
        if (!node.parentElement?.closest('script, style') && phrases.has(node.data.trim())) {
            staticText.set(node, node.data);
        }
    }
    const liveText = new Map();
    window.portText = translate;
    window.portSetText = (element, source) => {
        liveText.set(element, source);
        element.textContent = translate(source);
    };
    const picker = document.getElementById('port-language');
    function refresh() {
        document.documentElement.lang = language;
        picker.value = language;
        for (const [node, source] of staticText) {
            node.data = source.replace(source.trim(), translate(source.trim()));
        }
        for (const [element, source] of liveText) element.textContent = translate(source);
    }
    picker.addEventListener('change', () => {
        if (!languages.includes(picker.value)) return;
        language = picker.value;
        storage.setItem('port-language', language);
        refresh();
    });
    refresh();
})();
