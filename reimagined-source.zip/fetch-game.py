import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

ORIGINAL = "https://html-classic.itch.zone/html/17838205/"
SCRIPTS = ("game", "player", "map", "ai", "audio", "effects", "ui")
ASSET_PATH = re.compile(r"\bassets/[\w./-]+\.(?:glb|png|jpe?g|mp3|ogg|wav|webp)\b")


def download(url):
    for attempt in range(3):
        try:
            with urlopen(url, timeout=45) as response:
                return response.read()
        except HTTPError as error:
            if error.code == 404 or attempt == 2:
                raise
        except (URLError, TimeoutError):
            if attempt == 2:
                raise
        time.sleep(attempt + 1)


def main():
    output = Path(sys.argv[1])
    output.mkdir(parents=True, exist_ok=True)

    def save(relative):
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.is_file():
            try:
                blob = download(ORIGINAL + relative)
            except HTTPError as error:
                if error.code == 404 and relative == "assets/images/screamer.jpg":
                    print("The unused fallback screamer.jpg is absent upstream")
                    return None
                raise RuntimeError(f"Could not fetch {relative}: {error.code}") from error
            target.write_bytes(blob)
        return target

    with ThreadPoolExecutor(max_workers=10) as pool:
        originals = list(pool.map(save, ["index.html", *(f"js/{name}.js" for name in SCRIPTS)]))
        assets = set()
        for original in originals:
            assets.update(ASSET_PATH.findall(original.read_text(encoding="utf-8")))
        if "assets/models/tinky.glb" not in assets or "assets/models/custard.glb" not in assets:
            raise SystemExit("The original release has changed")
        files = list(pool.map(save, sorted(assets)))
    print(f"Fetched {len(originals)} source files and {sum(p is not None for p in files)} game assets")


if __name__ == "__main__":
    main()
